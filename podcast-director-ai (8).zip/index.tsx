/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import * as QRCode from 'qrcode';

const appContainer = document.getElementById(
  'app-container',
// FIX: Corrected typo from HTMLDivElenment to HTMLDivElement
) as HTMLDivElement;
const loadingOverlay = document.getElementById(
  'loading-overlay',
) as HTMLDivElement;
const loadingMessage = document.getElementById(
  'loading-message',
) as HTMLParagraphElement;

// --- SIMULATED SIGNALING SERVER ---
class SimulatedSignaling {
    private listeners: Map<string, Function[]> = new Map();
    private static instance: SimulatedSignaling;

    public static getInstance(): SimulatedSignaling {
        if (!SimulatedSignaling.instance) {
            SimulatedSignaling.instance = new SimulatedSignaling();
        }
        return SimulatedSignaling.instance;
    }

    on(event: string, callback: Function) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event)!.push(callback);
    }
    
    off(event: string, callback?: Function) {
        if (!this.listeners.has(event)) return;
        if (callback) {
            const eventListeners = this.listeners.get(event)!.filter(cb => cb !== callback);
            this.listeners.set(event, eventListeners);
        } else {
            this.listeners.delete(event);
        }
    }

    send(event: string, ...args: any[]) {
        if (this.listeners.has(event)) {
            this.listeners.get(event)!.forEach(callback => {
                try {
                    callback(...args);
                } catch (e) {
                    console.error(`Error in signaling listener for event '${event}':`, e);
                }
            });
        }
    }
}
const signalingChannel = SimulatedSignaling.getInstance();


// --- STATE MANAGEMENT ---
interface CameraSlot {
  id: number;
  stream: MediaStream | null;
  status: 'disconnected' | 'connected' | 'paused';
  isMuted: boolean;
  volume: number; // Volume from 0 to 1
  resolution: string;
  frameRate: number;
  audioDeviceId: string;
  audioLevel: number; // For VU meter, 0-1
  guestName: string;
  guestTitle: string;
  // For audio analysis - managed by director view
  audioContext?: AudioContext;
  analyser?: AnalyserNode;
  audioSource?: MediaStreamAudioSourceNode;
  audioDataArray?: Uint8Array;
}

interface SuggestedClip {
    start_time: number;
    end_time: number;
    suggested_title: string;
    reason_for_selection: string;
}

const params = new URLSearchParams(window.location.search);
const sessionCodeFromUrl = params.get('session');

const appState = {
  isHost: sessionCodeFromUrl === null,
  view: 'landing', // 'landing' | 'director' | 'camera' | 'share' | 'post-production'
  role: null as 'director' | 'camera' | null,
  director: {
    cameras: [] as CameraSlot[],
    sessionCode: null as string | null,
    isLive: false,
    isPaused: false,
    autoSwitch: false,
    showOverlays: true,
    liveCameraId: null as number | null,
    aiInterval: null as number | null,
    mediaRecorder: null as MediaRecorder | null,
    recordedChunks: [] as Blob[],
    fullRecordingBlob: null as Blob | null,
    recordingDuration: 0,
    isAnalyzing: false,
    suggestedClips: [] as SuggestedClip[],
    settingsModalCameraId: null as number | null,
    audioVisualizerFrameId: null as number | null,
    hasInitializedListeners: false,
  },
  camera: {
    localStream: null as MediaStream | null,
    isConnected: false,
    connectedCameraId: null as number | null,
    isPreviewActive: false,
    facingMode: 'environment' as 'user' | 'environment',
    enteredCode: '',
    isPausedByOperator: false,
    isLive: false,
    hasInitializedListeners: false,
  },
};

// --- GEMINI AI SETUP ---
let ai: GoogleGenAI | null = null;
try {
  ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
} catch (e) {
  console.error('Failed to initialize GoogleGenAI. Check API_KEY.', e);
  alert('Error: Could not initialize AI. Please ensure the API key is set correctly.');
}

// --- UTILITY FUNCTIONS ---
const generateSessionCode = (): string => Math.random().toString(36).substring(2, 8).toUpperCase();
const showLoading = (message: string) => { loadingMessage.textContent = message; loadingOverlay.classList.remove('hidden'); };
const hideLoading = () => { loadingOverlay.classList.add('hidden'); };

const base64Encode = async (stream: MediaStream): Promise<string | null> => {
  const video = document.createElement('video');
  try {
    video.srcObject = stream;
    video.muted = true;
    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => video.play().then(resolve).catch(reject);
      video.onerror = (e) => reject(`Video error: ${e}`);
    });
    await new Promise((r) => setTimeout(r, 100));
    if (video.videoWidth === 0 || video.videoHeight === 0) return null;
    const MAX_WIDTH = 480;
    const scale = MAX_WIDTH / video.videoWidth;
    const canvas = document.createElement('canvas');
    canvas.width = MAX_WIDTH;
    canvas.height = video.videoHeight * scale;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
  } catch (error) {
    console.error('Error encoding frame:', error);
    return null;
  } finally {
    video.pause();
    video.srcObject = null;
  }
};

// --- AUDIO ANALYSIS ---
function stopAudioVisualizer() {
    if (appState.director.audioVisualizerFrameId) cancelAnimationFrame(appState.director.audioVisualizerFrameId);
    appState.director.audioVisualizerFrameId = null;
    appState.director.cameras.forEach(cam => {
        if (cam.audioContext && cam.audioContext.state !== 'closed') cam.audioContext.close();
        Object.assign(cam, { audioContext: undefined, analyser: undefined, audioSource: undefined, audioDataArray: undefined, audioLevel: 0 });
    });
}

function startAudioVisualizer() {
    if (appState.director.audioVisualizerFrameId) return; 
    const loop = () => {
        appState.director.cameras.forEach(cam => {
            const hasAudio = cam.stream?.getAudioTracks().find(t => t.readyState === 'live');
            if (cam.status === 'connected' && hasAudio) {
                if (!cam.audioContext || cam.audioContext.state === 'closed') {
                    try {
                        cam.audioContext = new AudioContext();
                        cam.audioSource = cam.audioContext.createMediaStreamSource(cam.stream!);
                        cam.analyser = cam.audioContext.createAnalyser();
                        cam.analyser.fftSize = 32;
                        cam.audioDataArray = new Uint8Array(cam.analyser.frequencyBinCount);
                        cam.audioSource.connect(cam.analyser);
                    } catch(e) { console.error("Error setting up audio context:", e); cam.audioContext = undefined; }
                }
                if (cam.analyser && cam.audioDataArray) {
                    cam.analyser.getByteFrequencyData(cam.audioDataArray);
                    const avg = cam.audioDataArray.reduce((a, b) => a + b, 0) / cam.audioDataArray.length;
                    cam.audioLevel = Math.min(avg / 128, 1);
                    const el = document.getElementById(`vu-level-${cam.id}`);
                    if (el) el.style.width = `${cam.audioLevel * 100}%`;
                }
            } else {
                if (cam.audioContext && cam.audioContext.state !== 'closed') { cam.audioContext.close(); cam.audioContext = undefined; }
                if (cam.audioLevel !== 0) {
                    cam.audioLevel = 0;
                    const el = document.getElementById(`vu-level-${cam.id}`);
                    if (el) el.style.width = `0%`;
                }
            }
        });
        appState.director.audioVisualizerFrameId = requestAnimationFrame(loop);
    };
    loop();
}

// --- AI DIRECTOR LOGIC ---
async function aiAutoSwitchScene() {
  if (!ai || !appState.director.isLive || appState.director.isPaused || !appState.director.autoSwitch) return;
  const activeCameras = appState.director.cameras.filter(c => c.stream && c.status === 'connected');
  if (activeCameras.length < 2) return;

  try {
    const imageParts = (await Promise.all(activeCameras.map(async cam => ({ id: cam.id, b64: await base64Encode(cam.stream!) }))))
      .filter(p => p.b64)
      .map(p => ({ inlineData: { mimeType: 'image/jpeg', data: p.b64! } }));
    
    if (imageParts.length < 1) return;

    const cameraInfo = activeCameras.map(cam => `- Camera ${cam.id}: Guest is '${cam.guestName || 'Unknown'}'. Audio Level: ${cam.audioLevel.toFixed(2)} ${cam.audioLevel > 0.1 ? '(speaking)' : '(silent)'}`).join('\n');
    const activeCameraIds = activeCameras.map(c => c.id);
    const promptText = `You are an expert AI live video director. Your task is to select the next camera to switch to and decide if you should show their nameplate ('lower third').
Current Live Camera: Camera ${appState.director.liveCameraId}. Active Cameras: ${activeCameraIds.join(', ')}.
Analyze visuals and camera info:
${cameraInfo}
Rules:
1. HIGHEST PRIORITY: Switch to the person actively speaking. Use audio levels as the primary cue.
2. MUST choose a camera_id from [${activeCameraIds.join(', ')}].
3. MUST NOT suggest the Current Live Camera (ID ${appState.director.liveCameraId}).
4. If overlays are enabled (show_overlays is true), decide if it's a good moment to show the nameplate (e.g., a new speaker).
5. 'show_lower_third' must be false if overlays are disabled.
6. Respond ONLY with a single JSON object.
Overlays Enabled: ${appState.director.showOverlays}
Format: {"camera_id": <number>, "show_lower_third": <boolean>}.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [...imageParts, { text: promptText }] },
      config: {
        responseMimeType: 'application/json',
        responseSchema: { type: Type.OBJECT, properties: { camera_id: { type: Type.NUMBER }, show_lower_third: { type: Type.BOOLEAN } }, required: ['camera_id', 'show_lower_third'] },
      },
    });

    const decision = JSON.parse(response.text.trim()) as { camera_id: number; show_lower_third: boolean };
    const suggestedCamera = activeCameras.find(c => c.id === decision.camera_id);
    if (suggestedCamera && suggestedCamera.id !== appState.director.liveCameraId) {
      setLiveCamera(suggestedCamera.id, { showOverlay: decision.show_lower_third });
    }
  } catch (error) { console.error('AI Director Error:', error); }
}

// --- CORE APP LOGIC ---
function setLiveCamera(cameraId: number | null, options?: { showOverlay?: boolean }) {
  const oldLiveCameraId = appState.director.liveCameraId;
  const newLiveCam = appState.director.cameras.find(c => c.id === cameraId);
  
  if (cameraId === null || (newLiveCam?.stream && newLiveCam.status === 'connected')) {
    appState.director.liveCameraId = cameraId;
    if (appState.view === 'director') {
        const liveOutputContainer = document.querySelector('.live-output-container');
        const liveOutput = document.getElementById('live-output') as HTMLVideoElement;
        if (liveOutput && liveOutputContainer) {
            liveOutput.srcObject = newLiveCam?.stream ?? null;
            if (newLiveCam) {
              liveOutput.volume = newLiveCam.isMuted ? 0 : newLiveCam.volume;
              liveOutput.play().catch(e => { if (e.name !== 'AbortError') console.error('Live output play error', e); });
            }
            document.querySelectorAll('.camera-slot').forEach(slot => slot.classList.remove('live'));
            if (cameraId) document.getElementById(`camera-slot-${cameraId}`)?.classList.add('live');
            if (options?.showOverlay && appState.director.showOverlays && newLiveCam?.guestName) {
                const existing = document.querySelector('.lower-third-overlay');
                if (existing) existing.remove();
                const overlay = document.createElement('div');
                overlay.className = 'lower-third-overlay';
                overlay.innerHTML = `<div class="guest-name">${newLiveCam.guestName}</div><div class="guest-title">${newLiveCam.guestTitle}</div>`;
                liveOutputContainer.appendChild(overlay);
                setTimeout(() => overlay.classList.add('visible'), 100);
                setTimeout(() => { overlay.classList.remove('visible'); setTimeout(() => overlay.remove(), 500); }, 7000);
            }
        }
    }
    if (oldLiveCameraId) signalingChannel.send(`camera:${oldLiveCameraId}:tally-update`, false);
    if (cameraId) signalingChannel.send(`camera:${cameraId}:tally-update`, true);
  }
}

function startRecording() {
  const liveOutput = document.getElementById('live-output') as HTMLVideoElement;
  if (!liveOutput || !liveOutput.srcObject) { alert('Cannot start recording, no live camera selected.'); return; }
  
  const audioContext = new AudioContext();
  const destinations = audioContext.createMediaStreamDestination();
  appState.director.cameras.forEach(cam => {
      if (cam.stream && !cam.isMuted && cam.stream.getAudioTracks().length > 0) {
          const source = audioContext.createMediaStreamSource(cam.stream);
          const gainNode = audioContext.createGain();
          gainNode.gain.value = cam.volume;
          source.connect(gainNode).connect(destinations);
      }
  });
  const combinedStream = new MediaStream([...(liveOutput.srcObject as MediaStream).getVideoTracks(), ...destinations.stream.getTracks()]);

  appState.director.mediaRecorder = new MediaRecorder(combinedStream, { mimeType: 'video/webm; codecs=vp9,opus' });
  appState.director.recordedChunks = [];
  appState.director.mediaRecorder.ondataavailable = e => { if (e.data.size > 0) appState.director.recordedChunks.push(e.data); };
  appState.director.mediaRecorder.onstop = () => {
    appState.director.fullRecordingBlob = new Blob(appState.director.recordedChunks, { type: 'video/webm' });
    audioContext.close();
    renderView('post-production');
  };
  appState.director.mediaRecorder.start();
}

function toggleLive() {
  if (appState.director.cameras.filter(c => c.status === 'connected').length === 0 && !appState.director.isLive) {
    alert('Connect at least one camera before going live.'); return;
  }
  appState.director.isLive = !appState.director.isLive;
  appContainer.classList.toggle('fullscreen-live', appState.director.isLive);

  if (appState.director.isLive) {
    if (!appState.director.liveCameraId) {
      const firstConnected = appState.director.cameras.find(c => c.status === 'connected');
      if (firstConnected) setLiveCamera(firstConnected.id);
    }
    startRecording();
    if (appState.director.autoSwitch) {
      appState.director.aiInterval = window.setInterval(aiAutoSwitchScene, 15000);
      aiAutoSwitchScene();
    }
  } else {
    if (appState.director.aiInterval) clearInterval(appState.director.aiInterval);
    appState.director.aiInterval = null;
    if (appState.director.mediaRecorder && appState.director.mediaRecorder.state === 'recording') {
        const liveOutput = document.getElementById('live-output') as HTMLVideoElement;
        appState.director.recordingDuration = liveOutput.currentTime;
        appState.director.mediaRecorder.stop();
    }
    setLiveCamera(null);
  }
  renderView('director');
}

async function analyzeRecording() {
    if (!ai || !appState.director.fullRecordingBlob) return;
    appState.director.isAnalyzing = true;
    renderView('post-production');
    try {
        const prompt = `You are an expert social media video editor. You have a podcast recording that is ${Math.round(appState.director.recordingDuration)} seconds long. Your task is to find the 3 most interesting, potentially viral moments.
        Rules:
        1. Suggest 3 distinct clips, each 30-90 seconds long.
        2. Provide precise start_time and end_time in seconds for each.
        3. Create a catchy, "viral-style" title for each.
        4. Provide a short 'reason_for_selection' (e.g., "High energy debate", "Funny moment").
        5. Times MUST be within the video's duration.
        6. Respond ONLY with a single JSON object with a 'clips' array.`;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash', contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: { type: Type.OBJECT, properties: { clips: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { start_time: { type: Type.NUMBER }, end_time: { type: Type.NUMBER }, suggested_title: { type: Type.STRING }, reason_for_selection: { type: Type.STRING } }, required: ['start_time', 'end_time', 'suggested_title', 'reason_for_selection'] } } }, required: ['clips'] }
            }
        });
        appState.director.suggestedClips = (JSON.parse(response.text.trim()) as { clips: SuggestedClip[] }).clips || [];
    } catch (error) { console.error("Error analyzing recording:", error); alert("AI analysis failed."); appState.director.suggestedClips = []; } 
    finally { appState.director.isAnalyzing = false; renderView('post-production'); }
}

async function exportClip(clip: SuggestedClip) {
    if (!appState.director.fullRecordingBlob) return;
    showLoading(`Processing clip...`);
    try {
        const fullVideoUrl = URL.createObjectURL(appState.director.fullRecordingBlob);
        const video = document.createElement('video');
        video.muted = true;
        const stream = (video as any).captureStream ? (video as any).captureStream() : (video as any).mozCaptureStream();
        if (!stream) throw new Error('captureStream API not supported');
        const clipRecorder = new MediaRecorder(stream, { mimeType: 'video/webm; codecs=vp9,opus' });
        const chunks: Blob[] = [];
        clipRecorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
        clipRecorder.onstop = () => {
            const clipBlob = new Blob(chunks, { type: 'video/webm' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(clipBlob);
            a.download = `${clip.suggested_title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.webm`;
            a.click();
            URL.revokeObjectURL(a.href);
            URL.revokeObjectURL(fullVideoUrl);
            hideLoading();
        };
        const onSeeked = async () => { video.removeEventListener('seeked', onSeeked); clipRecorder.start(); await video.play(); };
        const onTimeUpdate = () => { if (video.currentTime >= clip.end_time) { video.removeEventListener('timeupdate', onTimeUpdate); if (clipRecorder.state === 'recording') clipRecorder.stop(); video.pause(); } };
        const onLoadedData = () => { video.removeEventListener('loadeddata', onLoadedData); video.addEventListener('seeked', onSeeked); video.addEventListener('timeupdate', onTimeUpdate); video.currentTime = clip.start_time; };
        video.addEventListener('loadeddata', onLoadedData);
        video.src = fullVideoUrl;
    } catch (error) { console.error('Error exporting clip:', error); alert('Failed to export clip.'); hideLoading(); }
}

// --- RENDERING LOGIC ---
function renderView(view: string) {
  appState.view = view;
  appContainer.innerHTML = '';
  appContainer.className = '';
  switch (view) {
    case 'director': renderDirectorView(); break;
    case 'camera': renderCameraView(); break;
    case 'share': renderShareView(); break;
    case 'post-production': renderPostProductionView(); break;
    default: renderLandingPage(); break;
  }
}

function renderLandingPage() {
    appContainer.innerHTML = `
        <div class="landing-view">
            <h1><i class="fa-solid fa-podcast"></i> Podcast Director AI</h1>
            <p>Your AI-powered multi-camera podcast studio. One device is the director, others connect as cameras. The AI Director intelligently switches scenes to create a dynamic recording.</p>
            <div class="role-selection">
                <button id="director-btn" class="btn"><i class="fa-solid fa-chair"></i> Become Director</button>
                <button id="camera-btn" class="btn"><i class="fa-solid fa-camera"></i> Connect as Camera</button>
                <button id="share-btn" class="btn btn-secondary"><i class="fa-solid fa-share-nodes"></i> Share Link & QR Code</button>
            </div>
        </div>
    `;
    document.getElementById('director-btn')!.onclick = () => { appState.role = 'director'; renderView('director'); };
    document.getElementById('camera-btn')!.onclick = () => { appState.role = 'camera'; renderView('camera'); };
    document.getElementById('share-btn')!.onclick = () => renderView('share');
}

function renderShareView() {
    const { sessionCode } = appState.director;
    appContainer.innerHTML = `
        <div class="share-view">
             <div class="share-panel">
                 <h3><i class="fa-solid fa-share-nodes"></i> Connection Info</h3>
                 <p>Share this link or QR code with your camera operators to have them join your session.</p>
                 ${window.location.hostname === 'localhost' ? `<div class="local-network-notice"><i class="fa-solid fa-circle-info"></i><div><strong>Using Localhost?</strong><p>For QR/Link to work on other devices, replace 'localhost' in your browser URL with your computer's local IP address (e.g., 192.168.1.5) and reload.</p></div></div>` : ''}
                 <div class="session-code-container"><span id="session-code">${sessionCode}</span></div>
                 <div class="qr-code-container"><img id="qr-code" src="" alt="QR Code"><p>Scan to Join as Camera</p></div>
                 <div class="share-buttons">
                    <button id="copy-link-btn" class="btn"><i class="fa-solid fa-copy"></i> Copy Link</button>
                    <button id="share-btn" class="btn"><i class="fa-solid fa-paper-plane"></i> Share</button>
                 </div>
             </div>
             <button id="back-btn" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Home</button>
        </div>
    `;
    const url = `${window.location.origin}${window.location.pathname}?session=${sessionCode}`;
    const qrImg = document.getElementById('qr-code') as HTMLImageElement;
    QRCode.toDataURL(url, { width: 160, margin: 1 }, (err, dataUrl) => { if (!err) qrImg.src = dataUrl; });

    document.getElementById('copy-link-btn')!.onclick = () => navigator.clipboard.writeText(url).then(() => alert('Link Copied!'));
    document.getElementById('share-btn')!.onclick = () => navigator.share && navigator.share({ title: 'Join My Podcast!', url });
    document.getElementById('back-btn')!.onclick = () => renderView('landing');
}


function renderDirectorView() {
    const directorState = appState.director;
    const isLive = directorState.isLive;
    appContainer.innerHTML = `
      <header class="app-header">
        <h1 class="app-title"><i class="fa-solid fa-satellite-dish"></i> Director View</h1>
        <div class="nav-links">
            <button id="back-to-home-btn" class="nav-btn"><i class="fa-solid fa-house"></i> Back to Home</button>
        </div>
      </header>
      <div class="director-view">
        <div class="main-content">
          <div class="live-panel">
            <div class="live-output-container">
              <video id="live-output" autoplay playsinline></video>
              ${isLive ? `<div class="live-indicator blinking">LIVE</div>` : ''}
            </div>
          </div>
        </div>
        <div class="main-controls-panel">
            <span class="control-label">Manual</span>
            <label class="switch"><input type="checkbox" id="ai-switch" ${directorState.autoSwitch ? 'checked' : ''}><span class="slider round"></span></label>
            <span class="control-label">AI Director</span>
            <div class="control-divider"></div>
            <button id="live-btn" class="live-control-btn ${isLive ? 'live' : ''}">${isLive ? '<i class="fa-solid fa-stop"></i> Stop Live' : '<i class="fa-solid fa-play"></i> Start Live'}</button>
            <button id="pause-btn" class="cam-control-btn text-btn" ${!isLive ? 'disabled' : ''}><i class="fa-solid fa-pause"></i> Pause</button>
            <div class="control-divider"></div>
            <span class="control-label">Overlays Off</span>
            <label class="switch"><input type="checkbox" id="overlay-switch" ${directorState.showOverlays ? 'checked' : ''}><span class="slider round"></span></label>
            <span class="control-label">Overlays On</span>
        </div>
        <div class="camera-strip">
          ${directorState.cameras.map(cam => `
            <div id="camera-slot-${cam.id}" class="camera-slot ${cam.status === 'connected' ? 'connected' : ''} ${directorState.liveCameraId === cam.id ? 'live' : ''}">
              <div class="camera-slot-header"><i class="fa-solid fa-video"></i> Camera ${cam.id}</div>
              <div class="video-wrapper">
                  <video id="video-${cam.id}" autoplay playsinline muted></video>
                  ${cam.status === 'disconnected' ? `<div class="connection-info"><i class="fa-solid fa-power-off"></i><span>Waiting for camera...</span></div>` : ''}
                  ${cam.status === 'paused' ? `<div class="status-overlay">PAUSED</div>` : ''}
              </div>
              <div class="camera-slot-footer">
                  <div class="guest-info-inputs">
                      <input type="text" id="guest-name-${cam.id}" placeholder="Guest Name" value="${cam.guestName}" ${cam.status !== 'connected' ? 'disabled' : ''}>
                      <input type="text" id="guest-title-${cam.id}" placeholder="Title / Topic" value="${cam.guestTitle}" ${cam.status !== 'connected' ? 'disabled' : ''}>
                  </div>
                  <div class="vu-meter"><div id="vu-level-${cam.id}" class="vu-meter-level"></div></div>
                  <div class="camera-slot-controls">
                      <div class="volume-control">
                          <button id="mute-btn-${cam.id}" class="cam-control-btn ${cam.isMuted ? 'muted-icon' : ''}" ${cam.status !== 'connected' ? 'disabled' : ''}><i class="fa-solid ${cam.isMuted ? 'fa-volume-xmark' : 'fa-volume-high'}"></i></button>
                          <input id="volume-slider-${cam.id}" type="range" min="0" max="1" step="0.01" value="${cam.volume}" class="volume-slider" ${cam.status !== 'connected' ? 'disabled' : ''}>
                      </div>
                      <button id="pause-cam-btn-${cam.id}" class="cam-control-btn" ${cam.status !== 'connected' ? 'disabled' : ''}><i class="fa-solid ${cam.status === 'paused' ? 'fa-play' : 'fa-pause'}"></i></button>
                      <button id="settings-cam-btn-${cam.id}" class="cam-control-btn" ${cam.status !== 'connected' ? 'disabled' : ''}><i class="fa-solid fa-cog"></i></button>
                      <button id="disconnect-cam-btn-${cam.id}" class="cam-control-btn disconnect" ${cam.status !== 'connected' ? 'disabled' : ''}><i class="fa-solid fa-xmark"></i></button>
                  </div>
              </div>
            </div>`).join('')}
        </div>
      </div>
    `;

    // FIX: Ensure the live output video element gets the correct stream after a re-render.
    const liveOutput = document.getElementById('live-output') as HTMLVideoElement;
    if (directorState.liveCameraId && liveOutput) {
        const liveCam = directorState.cameras.find(c => c.id === directorState.liveCameraId);
        if (liveCam && liveCam.stream) {
            liveOutput.srcObject = liveCam.stream;
            liveOutput.volume = liveCam.isMuted ? 0 : liveCam.volume;
            liveOutput.play().catch(e => { if (e.name !== 'AbortError') console.error('Error playing live output on render:', e); });
        }
    }

    document.getElementById('live-btn')!.onclick = toggleLive;
    document.getElementById('pause-btn')!.onclick = () => { /* Pause logic */ };
    document.getElementById('ai-switch')!.onchange = (e) => { directorState.autoSwitch = (e.target as HTMLInputElement).checked; if (directorState.autoSwitch && directorState.isLive) { directorState.aiInterval = window.setInterval(aiAutoSwitchScene, 15000); aiAutoSwitchScene(); } else if (directorState.aiInterval) { clearInterval(directorState.aiInterval); directorState.aiInterval = null; } };
    document.getElementById('overlay-switch')!.onchange = (e) => { directorState.showOverlays = (e.target as HTMLInputElement).checked; };

    document.getElementById('back-to-home-btn')!.onclick = () => {
        if (directorState.isLive) {
            alert('Please stop the live recording before returning to the home screen.');
            return;
        }
        init();
    };

    directorState.cameras.forEach(cam => {
        const videoEl = document.getElementById(`video-${cam.id}`) as HTMLVideoElement;
        if (cam.stream && videoEl) videoEl.srcObject = cam.stream;
        document.getElementById(`camera-slot-${cam.id}`)!.onclick = (e) => { if (cam.status === 'connected' && e.target instanceof HTMLElement && !e.target.closest('button, input')) setLiveCamera(cam.id); };
        document.getElementById(`guest-name-${cam.id}`)!.oninput = (e) => cam.guestName = (e.target as HTMLInputElement).value;
        document.getElementById(`guest-title-${cam.id}`)!.oninput = (e) => cam.guestTitle = (e.target as HTMLInputElement).value;
        document.getElementById(`mute-btn-${cam.id}`)!.onclick = () => { cam.isMuted = !cam.isMuted; renderView('director'); };
        document.getElementById(`volume-slider-${cam.id}`)!.oninput = (e) => { cam.volume = parseFloat((e.target as HTMLInputElement).value); const liveOut = document.getElementById('live-output') as HTMLVideoElement; if(directorState.liveCameraId === cam.id) liveOut.volume = cam.volume; };
        document.getElementById(`pause-cam-btn-${cam.id}`)!.onclick = () => signalingChannel.send(`director:command:${cam.id}`, 'toggle-pause');
        document.getElementById(`disconnect-cam-btn-${cam.id}`)!.onclick = () => signalingChannel.send(`director:command:${cam.id}`, 'disconnect');
    });
    
    // FIX: Replaced buggy flickering logic with a stable timeout handler for controls.
    if (directorState.isLive) {
        appContainer.classList.add('fullscreen-live');
        let controlVisibilityTimeout: number | null = null;
        
        const showControlsAndSetTimeout = () => {
            appContainer.classList.add('controls-visible');
            if (controlVisibilityTimeout) clearTimeout(controlVisibilityTimeout);
            controlVisibilityTimeout = window.setTimeout(() => {
                appContainer.classList.remove('controls-visible');
            }, 3000); // Hide after 3 seconds of inactivity
        };
        
        // Show controls immediately when entering live mode
        showControlsAndSetTimeout();
        
        appContainer.onmousemove = showControlsAndSetTimeout;
        appContainer.onclick = showControlsAndSetTimeout; // Good for touch devices
    } else {
        appContainer.onmousemove = null;
        appContainer.onclick = null;
    }
}

function renderCameraView() {
    const camState = appState.camera;
    if (camState.isPreviewActive) {
        appContainer.innerHTML = `
            <div class="camera-operator-view ${camState.isLive ? 'is-live' : ''}" id="operator-view">
                <video id="camera-preview" autoplay playsinline muted></video>
                <div class="tally-light-overlay"></div>
                <div class="camera-operator-status">
                    <div class="status-chip ${camState.isLive ? 'live' : 'connected'}">
                        <i class="fa-solid ${camState.isLive ? 'fa-record-vinyl' : 'fa-check'}"></i>
                        ${camState.isLive ? 'LIVE' : 'Connected'}
                    </div>
                </div>
                ${camState.isPausedByOperator ? `<div class="camera-operator-paused-overlay">PAUSED</div>` : ''}
                <div class="camera-operator-controls">
                    <button id="flip-cam-btn" class="cam-control-btn" title="Flip Camera"><i class="fa-solid fa-camera-rotate"></i></button>
                    <button id="pause-op-btn" class="cam-control-btn" title="${camState.isPausedByOperator ? 'Resume' : 'Pause'}">${camState.isPausedByOperator ? '<i class="fa-solid fa-play"></i>' : '<i class="fa-solid fa-pause"></i>'}</button>
                    ${appState.isHost ? `<button id="go-to-director-btn" class="cam-control-btn" title="Go to Director View"><i class="fa-solid fa-desktop"></i></button>` : ''}
                    <button id="disconnect-op-btn" class="cam-control-btn disconnect" title="Disconnect"><i class="fa-solid fa-power-off"></i></button>
                </div>
            </div>
        `;
        const videoEl = document.getElementById('camera-preview') as HTMLVideoElement;
        if (camState.localStream) videoEl.srcObject = camState.localStream;
        document.getElementById('flip-cam-btn')!.onclick = async () => {
            camState.facingMode = camState.facingMode === 'user' ? 'environment' : 'user';
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: camState.facingMode }, audio: true });
            camState.localStream = stream;
            (document.getElementById('camera-preview') as HTMLVideoElement).srcObject = stream;
            signalingChannel.send('camera:stream-update', camState.connectedCameraId, stream);
        };
        document.getElementById('pause-op-btn')!.onclick = () => { 
            camState.isPausedByOperator = !camState.isPausedByOperator;
            signalingChannel.send('camera:status-update', camState.connectedCameraId, camState.isPausedByOperator ? 'paused' : 'connected');
            renderView('camera');
        };
        if (appState.isHost) {
            document.getElementById('go-to-director-btn')!.onclick = () => {
                appState.role = 'director';
                renderView('director');
            };
        }
        document.getElementById('disconnect-op-btn')!.onclick = () => {
            signalingChannel.send('camera:disconnect', camState.connectedCameraId);
            camState.localStream?.getTracks().forEach(track => track.stop());
            Object.assign(camState, { localStream: null, isConnected: false, connectedCameraId: null, isPreviewActive: false });
            renderView('landing');
        };
    } else {
        appContainer.innerHTML = `
            <div class="camera-view">
              <div class="camera-setup-view">
                <div class="connection-form">
                    <h2><i class="fa-solid fa-tower-broadcast"></i> Connect to Director</h2>
                    <p>Enter 6-character session code from the Director's screen.</p>
                    <input type="text" id="code-input" maxlength="6" value="${camState.enteredCode}">
                    <button id="start-preview-btn" class="btn"><i class="fa-solid fa-video"></i> Start Camera & Preview</button>
                    <button id="back-btn" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Home</button>
                </div>
              </div>
            </div>
        `;
        const input = document.getElementById('code-input') as HTMLInputElement;
        input.oninput = () => camState.enteredCode = input.value.toUpperCase();
        document.getElementById('start-preview-btn')!.onclick = async () => {
            if (camState.enteredCode.length !== 6) { alert('Please enter a valid 6-character code.'); return; }
            try {
                showLoading('Starting camera...');
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: true });
                camState.localStream = stream;
                camState.isPreviewActive = true;
                signalingChannel.send('camera:connect', camState.enteredCode, stream);
                renderView('camera');
            } catch (err) { console.error("Error getting media:", err); alert("Could not access camera. Please check permissions.");
            } finally { hideLoading(); }
        };
        document.getElementById('back-btn')!.onclick = () => renderView('landing');
    }
}

function renderPostProductionView() {
    const { isAnalyzing, suggestedClips, fullRecordingBlob } = appState.director;
    appContainer.innerHTML = `
      <header class="app-header">
        <h1 class="app-title"><i class="fa-solid fa-wand-magic-sparkles"></i> Post-Production</h1>
      </header>
      <div class="post-production-view">
        ${isAnalyzing ? `
          <div class="analysis-in-progress">
            <div class="spinner"></div>
            <h2><i class="fa-solid fa-robot"></i> AI is Analyzing Your Recording...</h2>
            <p>This may take a moment. The AI is creating a transcript and identifying the best moments to turn into shareable clips.</p>
          </div>` 
        : `
          <div class="clip-review-container">
            <div class="clip-review-header">
                <h2><i class="fa-solid fa-scissors"></i> AI Suggested Clips</h2>
                <div class="global-actions">
                    <button id="download-full-btn" class="btn btn-secondary"><i class="fa-solid fa-download"></i> Download Full Recording</button>
                    <button id="new-session-btn" class="btn"><i class="fa-solid fa-rotate-right"></i> New Session</button>
                </div>
            </div>
            ${suggestedClips.length > 0 ? `
              <div class="clips-grid">
                ${suggestedClips.map((clip, index) => `
                  <div class="clip-card">
                    <div class="clip-card-video">
                      <video id="clip-video-${index}" src="${URL.createObjectURL(fullRecordingBlob!)}#t=${clip.start_time},${clip.end_time}" controls></video>
                    </div>
                    <div class="clip-card-content">
                      <h3 class="clip-title">${clip.suggested_title}</h3>
                      <div class="clip-reason"><strong><i class="fa-solid fa-lightbulb"></i> AI Reason:</strong> ${clip.reason_for_selection}</div>
                      <button id="export-btn-${index}" class="btn export-btn"><i class="fa-solid fa-file-export"></i> Export Clip</button>
                    </div>
                  </div>
                `).join('')}
              </div>` 
            : `<p>AI could not identify any clips. You can still download the full recording.</p>`}
          </div>`
        }
      </div>
    `;
    if (!isAnalyzing) {
        document.getElementById('download-full-btn')!.onclick = () => {
            const a = document.createElement('a');
            a.href = URL.createObjectURL(fullRecordingBlob!);
            a.download = `podcast_recording_${new Date().toISOString()}.webm`;
            a.click();
            URL.revokeObjectURL(a.href);
        };
        document.getElementById('new-session-btn')!.onclick = () => {
            Object.assign(appState.director, { isLive: false, recordedChunks: [], fullRecordingBlob: null, suggestedClips: [] });
            init();
        };
        suggestedClips.forEach((clip, index) => {
            document.getElementById(`export-btn-${index}`)!.onclick = () => exportClip(clip);
        });
        if (suggestedClips.length === 0 && !appState.director.isAnalyzing && appState.director.fullRecordingBlob) {
             setTimeout(analyzeRecording, 500); // Start analysis if not already done
        }
    } else {
        setTimeout(analyzeRecording, 500); // Start analysis after render
    }
}

// --- INITIALIZATION ---
function init() {
  // Reset state
  Object.assign(appState.director, { cameras: [], sessionCode: null, isLive: false, isPaused: false, autoSwitch: false, showOverlays: true, liveCameraId: null, aiInterval: null, mediaRecorder: null, recordedChunks: [], fullRecordingBlob: null, recordingDuration: 0, isAnalyzing: false, suggestedClips: [], settingsModalCameraId: null, audioVisualizerFrameId: null, hasInitializedListeners: false });
  Object.assign(appState.camera, { localStream: null, isConnected: false, connectedCameraId: null, isPreviewActive: false, facingMode: 'environment', enteredCode: '', isPausedByOperator: false, isLive: false, hasInitializedListeners: false });
  stopAudioVisualizer();

  const sessionCode = sessionCodeFromUrl;
  
  // Always set up director listeners and generate a session code
  if (!appState.director.hasInitializedListeners) {
    appState.director.hasInitializedListeners = true;
    for (let i = 1; i <= 4; i++) appState.director.cameras.push({ id: i, stream: null, status: 'disconnected', isMuted: false, volume: 1, resolution: 'default', frameRate: 30, audioDeviceId: 'default', audioLevel: 0, guestName: '', guestTitle: '' });
    appState.director.sessionCode = generateSessionCode();

    signalingChannel.on('camera:connect', (code: string, stream: MediaStream) => {
        if (code !== appState.director.sessionCode) return;
        const availableSlot = appState.director.cameras.find(c => c.status === 'disconnected');
        if (availableSlot) {
            availableSlot.status = 'connected';
            availableSlot.stream = stream;
            signalingChannel.send('director:connected', availableSlot.id);
            if (!appState.director.audioVisualizerFrameId && appState.view === 'director') startAudioVisualizer();
            if(appState.view === 'director') renderView('director');
        }
    });
    signalingChannel.on('camera:disconnect', (camId: number) => {
        const cam = appState.director.cameras.find(c => c.id === camId);
        if (cam) { Object.assign(cam, { stream: null, status: 'disconnected', guestName: '', guestTitle: '' }); if (appState.director.liveCameraId === camId) setLiveCamera(null); if(appState.view === 'director') renderView('director'); }
    });
    signalingChannel.on('camera:status-update', (camId: number, status: 'connected' | 'paused') => {
        const cam = appState.director.cameras.find(c => c.id === camId);
        if (cam) { cam.status = status; if(appState.view === 'director') renderView('director'); }
    });
     signalingChannel.on('camera:stream-update', (camId: number, newStream: MediaStream) => {
        const cam = appState.director.cameras.find(c => c.id === camId);
        if (cam) { cam.stream = newStream; if(appState.view === 'director') renderView('director'); }
    });
  }

  // Camera Listeners
  if (!appState.camera.hasInitializedListeners) {
    appState.camera.hasInitializedListeners = true;
    signalingChannel.on('director:connected', (camId: number) => { 
        if(appState.role !== 'camera') return;
        appState.camera.isConnected = true; 
        appState.camera.connectedCameraId = camId; 
        renderView('camera'); 
    });
    // Re-register command listener with specific camera ID after connection
    signalingChannel.on('director:connected', (camId: number) => {
        if (appState.role !== 'camera') return;
        signalingChannel.on(`director:command:${camId}`, (command: 'toggle-pause' | 'disconnect') => {
            if (command === 'toggle-pause') { (document.getElementById('pause-op-btn') as HTMLButtonElement)?.click(); }
            if (command === 'disconnect') { (document.getElementById('disconnect-op-btn') as HTMLButtonElement)?.click(); }
        });
        signalingChannel.on(`camera:${camId}:tally-update`, (isLive: boolean) => { 
            appState.camera.isLive = isLive; 
            document.getElementById('operator-view')?.classList.toggle('is-live', isLive);
            const statusChip = document.querySelector('.status-chip');
            if (statusChip) {
                statusChip.innerHTML = `<i class="fa-solid ${isLive ? 'fa-record-vinyl' : 'fa-check'}"></i> ${isLive ? 'LIVE' : 'Connected'}`;
                statusChip.className = `status-chip ${isLive ? 'live' : 'connected'}`;
            }
        });
    });
  }

  // Initial view routing
  if (sessionCode) {
    appState.role = 'camera';
    appState.camera.enteredCode = sessionCode.toUpperCase();
    renderView('camera');
  } else {
    renderView('landing');
  }
}

init();