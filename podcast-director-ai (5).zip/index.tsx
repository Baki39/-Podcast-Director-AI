/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";

const appContainer = document.getElementById(
  'app-container',
) as HTMLDivElement;
const loadingOverlay = document.getElementById(
  'loading-overlay',
) as HTMLDivElement;
const loadingMessage = document.getElementById(
  'loading-message',
) as HTMLParagraphElement;

// --- STATE MANAGEMENT ---
interface CameraSlot {
  id: number;
  code: string;
  stream: MediaStream | null;
  status: 'disconnected' | 'connected' | 'paused';
  duration: number; // Duration in seconds
  isMuted: boolean;
  volume: number; // Volume from 0 to 1
}

const appState = {
  view: 'landing', // 'landing' | 'director' | 'camera'
  role: null as 'director' | 'camera' | null,
  director: {
    cameras: [] as CameraSlot[],
    isLive: false,
    isPaused: false,
    autoSwitch: false,
    liveCameraId: null as number | null,
    aiInterval: null as number | null,
    mediaRecorder: null as MediaRecorder | null,
    recordedChunks: [] as Blob[],
  },
  camera: {
    localStream: null as MediaStream | null,
    isConnected: false,
    connectedCameraId: null as number | null,
    isPreviewActive: false,
    facingMode: 'environment' as 'user' | 'environment',
    enteredCode: '', // Store the code before previewing
    isPausedByOperator: false, // For local pause in camera view
  },
};

// --- GEMINI AI SETUP ---
let ai: GoogleGenAI | null = null;
try {
  ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
} catch (e) {
  console.error(
    'Failed to initialize GoogleGenAI. Check API_KEY environment variable.',
    e,
  );
  alert(
    'Error: Could not initialize AI. Please ensure the API key is set correctly.',
  );
}

// --- UTILITY FUNCTIONS ---
const generateCode = (): string =>
  Math.floor(1000 + Math.random() * 9000).toString();

const showLoading = (message: string) => {
  loadingMessage.textContent = message;
  loadingOverlay.classList.remove('hidden');
};

const hideLoading = () => {
  loadingOverlay.classList.add('hidden');
};

const base64Encode = async (
  stream: MediaStream,
): Promise<string | null> => {
  const video = document.createElement('video');
  try {
    video.srcObject = stream;
    video.muted = true;

    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => {
        video.play().then(resolve).catch(reject);
      };
      video.onerror = (e) => reject(`Video error: ${e}`);
    });

    await new Promise((r) => setTimeout(r, 100)); // Increased delay for stability

    if (video.videoWidth === 0 || video.videoHeight === 0) {
      console.error('Video has no dimensions. Cannot capture frame.');
      return null;
    }

    // Resize to a smaller resolution to avoid network errors
    const MAX_WIDTH = 480;
    const scale = MAX_WIDTH / video.videoWidth;
    const canvas = document.createElement('canvas');
    canvas.width = MAX_WIDTH;
    canvas.height = video.videoHeight * scale;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Use JPEG with quality compression
    return canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
  } catch (error) {
    console.error('Error encoding frame:', error);
    return null;
  } finally {
    video.pause();
    video.srcObject = null;
  }
};

// --- AI DIRECTOR LOGIC ---
async function aiAutoSwitchScene() {
  if (
    !ai ||
    !appState.director.isLive ||
    appState.director.isPaused ||
    !appState.director.autoSwitch
  )
    return;

  const activeCameras = appState.director.cameras.filter(
    (c) => c.stream && c.status === 'connected',
  );
  if (activeCameras.length < 2) return;

  console.log("AI Director: Analyzing scenes...");
  try {
    const imageParts = await Promise.all(
      activeCameras.map(async (cam) => {
        const b64 = await base64Encode(cam.stream!);
        return {
          id: cam.id,
          inlineData: b64
            ? { mimeType: 'image/jpeg', data: b64 }
            : undefined,
        };
      }),
    );

    const validImageParts = imageParts.filter((p) => p.inlineData);
    if (validImageParts.length < 1) {
      console.error('AI Director: Could not capture any valid image frames.');
      return;
    }

    const cameraPreferences = activeCameras
      .map(
        (cam) =>
          `Camera ${cam.id} preferred duration: ${cam.duration} seconds.`,
      )
      .join('\n');

    const activeCameraIds = activeCameras.map(c => c.id);

    const promptText = `You are an expert AI live video director. Your task is to select the next camera to switch to.
    
Current Live Camera: Camera ${appState.director.liveCameraId}.
Active Cameras: ${activeCameraIds.map((id) => `Camera ${id}`).join(', ')}.

User Preferences for Duration:
${cameraPreferences}

Analyze the provided images from each active camera. Based on the visuals and the user's preferred durations, decide which camera to switch to next to create the most engaging and dynamic viewing experience. Avoid monotonously switching between only two cameras if more are available.

Key Rules:
1. You MUST choose a camera_id from the list of Active Camera IDs: [${activeCameraIds.join(', ')}].
2. You MUST NOT suggest the Current Live Camera (ID ${appState.director.liveCameraId}).
3. Respond ONLY with a single JSON object. Format: {"camera_id": <number>}.`;
    
    const contents = [
      ...validImageParts.map(p => ({
          inlineData: p.inlineData!
      })),
      { text: promptText },
    ];


    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: contents },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            camera_id: { type: Type.NUMBER },
          },
        },
      },
    });

    const decisionText = response.text.trim();
    const decision = JSON.parse(decisionText) as { camera_id: number };

    const suggestedCamera = activeCameras.find(
      (c) => c.id === decision.camera_id,
    );
    if (
      suggestedCamera &&
      suggestedCamera.id !== appState.director.liveCameraId
    ) {
      console.log(`AI Director decided to switch to Camera ${suggestedCamera.id}`);
      setLiveCamera(suggestedCamera.id);
    } else {
        console.warn('AI Director made an invalid suggestion:', decision);
    }
  } catch (error) {
    console.error('AI Director Error:', error);
  }
}

// --- CORE APP LOGIC ---

function setLiveCamera(cameraId: number) {
  const liveOutput = document.getElementById(
    'live-output',
  ) as HTMLVideoElement;
  if (!liveOutput) return;

  const newLiveCam = appState.director.cameras.find((c) => c.id === cameraId);
  if (newLiveCam?.stream && newLiveCam.status === 'connected') {
    appState.director.liveCameraId = cameraId;
    liveOutput.srcObject = newLiveCam.stream;
    liveOutput.volume = newLiveCam.isMuted ? 0 : newLiveCam.volume;
    liveOutput.play().catch((e) => console.error('Live output play error', e));

    document.querySelectorAll('.camera-slot').forEach((slot) => {
      slot.classList.remove('live');
    });
    document
      .getElementById(`camera-slot-${cameraId}`)
      ?.classList.add('live');
    
    // In our simulation, re-render the camera view if it's active to update the tally light
    if (appState.camera.isConnected && appState.camera.connectedCameraId === cameraId) {
        renderView('camera');
    }
  }
}

function startRecording() {
  const liveOutput = document.getElementById(
    'live-output',
  ) as HTMLVideoElement;
  if (!liveOutput || !liveOutput.srcObject) {
    alert('Cannot start recording, no live camera selected.');
    return;
  }
  
  const audioContext = new AudioContext();
  const destinations = audioContext.createMediaStreamDestination();

  appState.director.cameras.forEach(cam => {
      if (cam.stream && !cam.isMuted && cam.stream.getAudioTracks().length > 0) {
          const source = audioContext.createMediaStreamSource(cam.stream);
          const gainNode = audioContext.createGain();
          gainNode.gain.value = cam.volume;
          source.connect(gainNode);
          gainNode.connect(destinations);
      }
  });

  const videoStream = (liveOutput.srcObject as MediaStream).getVideoTracks();
  const combinedStream = new MediaStream([...videoStream, ...destinations.stream.getTracks()]);


  appState.director.mediaRecorder = new MediaRecorder(combinedStream, {
    mimeType: 'video/webm; codecs=vp9,opus',
  });
  appState.director.recordedChunks = [];

  appState.director.mediaRecorder.ondataavailable = (event) => {
    if (event.data.size > 0) {
      appState.director.recordedChunks.push(event.data);
    }
  };

  appState.director.mediaRecorder.onstop = () => {
    const blob = new Blob(appState.director.recordedChunks, {
      type: 'video/webm',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = `podcast-recording-${new Date().toISOString()}.webm`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    audioContext.close();
  };

  appState.director.mediaRecorder.start();
}

function toggleLive() {
  const liveBtn = document.getElementById('live-btn') as HTMLButtonElement;
  const liveIndicator = document.querySelector('.live-indicator');

  const connectedCount = appState.director.cameras.filter(
    (c) => c.status === 'connected',
  ).length;
  if (connectedCount === 0 && !appState.director.isLive) {
    alert('Connect at least one camera before going live.');
    return;
  }

  appState.director.isLive = !appState.director.isLive;
  
  appContainer.classList.toggle('fullscreen-live', appState.director.isLive);

  if (appState.director.isLive) {
    liveBtn.innerHTML = '<i class="fa-solid fa-stop"></i> Stop Recording';
    liveBtn.style.borderColor = 'var(--neon-pink)';
    liveIndicator?.classList.remove('hidden');
    liveIndicator?.classList.add('blinking');
    appContainer.classList.add('controls-visible');

    if (!appState.director.liveCameraId) {
      const firstConnected = appState.director.cameras.find(
        (c) => c.status === 'connected',
      );
      if (firstConnected) setLiveCamera(firstConnected.id);
    }

    startRecording();

    if (appState.director.autoSwitch) {
      appState.director.aiInterval = window.setInterval(
        aiAutoSwitchScene,
        15000,
      );
      aiAutoSwitchScene();
    }
  } else {
    liveBtn.innerHTML = '<i class="fa-solid fa-play"></i> Go Live';
    liveBtn.style.borderColor = 'var(--accent-color)';
    liveIndicator?.classList.add('hidden');
    liveIndicator?.classList.remove('blinking');
    appContainer.classList.remove('controls-visible');

    if (appState.director.aiInterval) {
      clearInterval(appState.director.aiInterval);
      appState.director.aiInterval = null;
    }
    if (
      appState.director.mediaRecorder &&
      appState.director.mediaRecorder.state !== 'inactive'
    ) {
      appState.director.mediaRecorder.stop();
    }
    appState.director.liveCameraId = null;
    const liveOutput = document.getElementById(
      'live-output',
    ) as HTMLVideoElement;
    if (liveOutput) liveOutput.srcObject = null;
    document.querySelectorAll('.camera-slot').forEach((s) => s.classList.remove('live'));
  }
}

function togglePause() {
  const pauseBtn = document.getElementById('pause-btn') as HTMLButtonElement;
  appState.director.isPaused = !appState.director.isPaused;
  const liveIndicator = document.querySelector('.live-indicator');
  
  appContainer.classList.toggle('controls-visible', appState.director.isPaused);

  if (appState.director.isPaused) {
    pauseBtn.innerHTML = '<i class="fa-solid fa-play"></i> Resume';
    if (appState.director.mediaRecorder?.state === 'recording')
      appState.director.mediaRecorder.pause();
    liveIndicator?.classList.remove('blinking');
    liveIndicator!.textContent = 'PAUSED';
  } else {
    pauseBtn.innerHTML = '<i class="fa-solid fa-pause"></i> Pause';
    if (appState.director.mediaRecorder?.state === 'paused')
      appState.director.mediaRecorder.resume();
    liveIndicator?.classList.add('blinking');
    liveIndicator!.textContent = 'LIVE';
  }
}

function toggleAutoSwitch() {
  appState.director.autoSwitch = !appState.director.autoSwitch;

  if (appState.director.isLive && !appState.director.isPaused) {
    if (appState.director.autoSwitch) {
      appState.director.aiInterval = window.setInterval(
        aiAutoSwitchScene,
        15000,
      );
      aiAutoSwitchScene();
    } else {
      if (appState.director.aiInterval) {
        clearInterval(appState.director.aiInterval);
        appState.director.aiInterval = null;
      }
    }
  }
}

function connectCameraByCode(code: string, stream: MediaStream): number | null {
  const cameraSlot = appState.director.cameras.find((c) => c.code === code && c.status === 'disconnected');
  if (cameraSlot) {
    cameraSlot.stream = stream;
    cameraSlot.status = 'connected';
    renderView('director');
    return cameraSlot.id;
  }
  return null;
}

function toggleCameraPause(cameraId: number) {
  const cam = appState.director.cameras.find((c) => c.id === cameraId);
  if (!cam || cam.status === 'disconnected') return;

  if (cam.status === 'connected') {
    cam.status = 'paused';
  } else if (cam.status === 'paused') {
    cam.status = 'connected';
  }

  if (cam.status === 'paused' && appState.director.liveCameraId === cam.id) {
    const liveOutput = document.getElementById(
      'live-output',
    ) as HTMLVideoElement;
    liveOutput.srcObject = null;
  }

  renderView('director');
}

function toggleCameraMute(cameraId: number) {
    const cam = appState.director.cameras.find(c => c.id === cameraId);
    if (!cam || !cam.stream) return;

    cam.isMuted = !cam.isMuted;
    
    cam.stream.getAudioTracks().forEach(track => {
        track.enabled = !cam.isMuted;
    });

    const liveOutput = document.getElementById('live-output') as HTMLVideoElement;
    if (appState.director.liveCameraId === cam.id) {
        liveOutput.volume = cam.isMuted ? 0 : cam.volume;
    }
    
    renderView('director');
}

function handleVolumeChange(cameraId: number, volume: number) {
    const cam = appState.director.cameras.find(c => c.id === cameraId);
    if (!cam) return;
    cam.volume = volume;
    
    const liveOutput = document.getElementById('live-output') as HTMLVideoElement;
    if (appState.director.liveCameraId === cam.id && !cam.isMuted) {
        liveOutput.volume = volume;
    }
}

function disconnectCamera(cameraId: number) {
  const cam = appState.director.cameras.find((c) => c.id === cameraId);
  if (!cam) return;

  cam.stream = null;
  cam.status = 'disconnected';
  cam.code = generateCode();

  if (appState.director.liveCameraId === cameraId) {
    appState.director.liveCameraId = null;
    const liveOutput = document.getElementById(
      'live-output',
    ) as HTMLVideoElement;
    if (liveOutput) liveOutput.srcObject = null;

    const nextCam = appState.director.cameras.find(
      (c) => c.status === 'connected',
    );
    if (nextCam) {
      setLiveCamera(nextCam.id);
    }
  }

  renderView('director');
}

async function startCameraPreview() {
  if (appState.camera.localStream) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ 
      video: { facingMode: appState.camera.facingMode }, 
      audio: true 
    });
    appState.camera.localStream = stream;
    appState.camera.isPreviewActive = true;
    renderView('camera');
  } catch (err) {
    console.error('Error accessing camera:', err);
    alert('Could not access camera. Please check permissions.');
  }
}

async function flipCamera() {
    appState.camera.facingMode = appState.camera.facingMode === 'user' ? 'environment' : 'user';
    if (appState.camera.localStream) {
        appState.camera.localStream.getTracks().forEach(track => track.stop());
    }
    const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: appState.camera.facingMode },
        audio: true,
    });
    appState.camera.localStream = stream;

    // Update stream in director if connected
    if (appState.camera.isConnected && appState.camera.connectedCameraId) {
        const camSlot = appState.director.cameras.find(c => c.id === appState.camera.connectedCameraId);
        if (camSlot) {
            camSlot.stream = stream;
        }
    }

    renderView('camera');
}

function toggleOperatorPause() {
    if (!appState.camera.isConnected || !appState.camera.connectedCameraId) return;

    appState.camera.isPausedByOperator = !appState.camera.isPausedByOperator;

    // Toggle local media tracks
    appState.camera.localStream?.getTracks().forEach(track => {
        track.enabled = !appState.camera.isPausedByOperator;
    });

    // Update the director's view of this camera's state
    const directorCamSlot = appState.director.cameras.find(c => c.id === appState.camera.connectedCameraId);
    if (directorCamSlot) {
        directorCamSlot.status = appState.camera.isPausedByOperator ? 'paused' : 'connected';
        // Re-render director view only if the user is in that view
        if (appState.role === 'director') {
            renderView('director');
        }
    }

    renderView('camera');
}

function stopCameraViewConnection() {
    if (appState.camera.localStream) {
        appState.camera.localStream.getTracks().forEach(track => track.stop());
        appState.camera.localStream = null;
    }
    if (appState.camera.isConnected && appState.camera.connectedCameraId) {
        disconnectCamera(appState.camera.connectedCameraId);
    }
    appState.camera.isConnected = false;
    appState.camera.isPreviewActive = false;
    appState.camera.connectedCameraId = null;
    appState.camera.enteredCode = ''; // Clear the stored code
    appState.camera.isPausedByOperator = false; // Reset pause state
    renderView('camera');
}


// --- RENDER FUNCTIONS ---
function renderHeader(currentView: 'director' | 'camera'): string {
  const switchButton =
    currentView === 'director'
      ? `<button id="switch-to-camera-btn" class="nav-btn"><i class="fa-solid fa-camera"></i> Camera View</button>`
      : `<button id="switch-to-director-btn" class="nav-btn"><i class="fa-solid fa-user-tie"></i> Director View</button>`;

  return `
    <header class="app-header">
      <h1 id="home-btn" class="app-title"><i class="fa-solid fa-signal-stream"></i> Podcast Director AI</h1>
      <nav class="nav-links">
        ${switchButton}
      </nav>
    </header>
  `;
}

function renderView(view: 'landing' | 'director' | 'camera') {
  appState.view = view;
  const currentScroll = {
      director: document.querySelector('.director-view')?.scrollTop,
      cameraStrip: document.querySelector('.camera-strip')?.scrollLeft
  };

  appContainer.innerHTML = '';


  switch (view) {
    case 'landing':
      appContainer.className = '';
      appContainer.innerHTML = `
        <div class="landing-view">
          <h1><i class="fa-solid fa-signal-stream"></i> Podcast Director AI</h1>
          <p>Your multi-camera podcast studio, powered by AI. Use one phone as your Director and connect up to four others as cameras.</p>
          <div class="role-selection">
            <button id="director-btn" class="btn"><i class="fa-solid fa-user-tie"></i> Start as Director</button>
            <button id="camera-btn" class="btn"><i class="fa-solid fa-camera"></i> Connect Camera</button>
          </div>
        </div>
      `;
      document
        .getElementById('director-btn')
        ?.addEventListener('click', () => {
          appState.role = 'director';
          renderView('director');
        });
      document.getElementById('camera-btn')?.addEventListener('click', () => {
        appState.role = 'camera';
        renderView('camera');
      });
      break;
    case 'director':
      if (appState.director.cameras.length === 0) {
        for (let i = 1; i <= 4; i++) {
          appState.director.cameras.push({
            id: i,
            code: generateCode(),
            stream: null,
            status: 'disconnected',
            duration: 15, // Default duration
            isMuted: false,
            volume: 0.8, // Default volume
          });
        }
      }

      appContainer.innerHTML = `
        ${renderHeader('director')}
        <div class="director-view">
          <div class="main-content">
            <div class="live-panel">
              <div class="live-output-container">
                <video id="live-output" autoplay></video>
                <div class="live-indicator hidden">LIVE</div>
                 <div class="controls cinematic-controls">
                  <button id="live-btn" class="btn"><i class="fa-solid fa-play"></i> Go Live</button>
                  <button id="pause-btn" class="btn"><i class="fa-solid fa-pause"></i> Pause</button>
                </div>
              </div>
            </div>
          </div>
          <div class="auto-switch-panel">
            <div class="auto-switch-container">
                <span>Manual</span>
                <label class="switch">
                    <input type="checkbox" id="auto-switch-checkbox" ${
                      appState.director.autoSwitch ? 'checked' : ''
                    }>
                    <span class="slider round"></span>
                </label>
                <span>AI Director</span>
            </div>
        </div>
          <div class="camera-strip">
            ${appState.director.cameras
              .map(
                (cam) => `
              <div id="camera-slot-${cam.id}" class="camera-slot ${
                cam.status
              }">
                  <div class="camera-slot-header">
                      <span><i class="fa-solid fa-video"></i> Camera ${
                        cam.id
                      }</span>
                  </div>
                  <div class="video-wrapper">
                      ${
                        cam.stream
                          ? `<video id="video-${cam.id}" autoplay muted></video>`
                          : ''
                      }
                      ${
                        cam.status === 'disconnected'
                          ? `
                          <div class="connection-info">
                              <div class="code-label">CODE</div>
                              <div class="code">${cam.code}</div>
                          </div>`
                          : ''
                      }
                      ${
                        cam.status === 'paused'
                          ? `
                          <div class="status-overlay">PAUSED</div>`
                          : ''
                      }
                  </div>
                   <div class="camera-slot-footer">
                      <div class="camera-duration-control">
                        <label for="duration-${
                          cam.id
                        }"><i class="fa-solid fa-clock"></i></label>
                        <input type="number" class="duration-input" id="duration-${
                          cam.id
                        }" value="${cam.duration}" min="5" max="60">
                        <span>s</span>
                      </div>
                      <div class="camera-slot-controls">
                          ${
                            cam.status !== 'disconnected'
                              ? `
                               <button id="mute-cam-${cam.id}" class="cam-control-btn ${cam.isMuted ? 'muted-icon' : ''}" title="${cam.isMuted ? 'Unmute Audio' : 'Mute Audio'}">
                                  <i class="fa-solid ${cam.isMuted ? 'fa-microphone-slash' : 'fa-microphone'}"></i>
                              </button>
                              <div class="volume-control">
                                <i class="fa-solid fa-volume-low"></i>
                                <input type="range" id="volume-${cam.id}" class="volume-slider" min="0" max="1" step="0.05" value="${cam.volume}" ${cam.isMuted ? 'disabled' : ''}>
                              </div>
                              <button id="pause-cam-${
                                cam.id
                              }" class="cam-control-btn" title="Pause/Resume Camera">
                                  <i class="fa-solid ${
                                    cam.status === 'paused'
                                      ? 'fa-play'
                                      : 'fa-pause'
                                  }"></i>
                              </button>
                              <button id="disconnect-cam-${
                                cam.id
                              }" class="cam-control-btn disconnect" title="Stop & Disconnect Camera">
                                  <i class="fa-solid fa-stop"></i>
                              </button>
                          `
                              : ''
                          }
                      </div>
                  </div>
              </div>`,
              )
              .join('')}
          </div>
        </div>`;

      document
        .getElementById('home-btn')
        ?.addEventListener('click', () => renderView('landing'));
      document
        .getElementById('switch-to-camera-btn')
        ?.addEventListener('click', () => renderView('camera'));
      document.getElementById('live-btn')?.addEventListener('click', toggleLive);
      document
        .getElementById('pause-btn')
        ?.addEventListener('click', togglePause);
      document
        .getElementById('auto-switch-checkbox')
        ?.addEventListener('change', toggleAutoSwitch);

      appState.director.cameras.forEach((cam) => {
        const videoEl = document.getElementById(
          `video-${cam.id}`,
        ) as HTMLVideoElement;
        if (cam.stream && videoEl) {
          videoEl.srcObject = cam.stream;
        }

        const slotEl = document.getElementById(`camera-slot-${cam.id}`);
        if (slotEl && cam.status === 'connected') {
          slotEl.addEventListener('click', (e) => {
            if ((e.target as HTMLElement).closest('.cam-control-btn, .camera-duration-control, .volume-control')) return;
            setLiveCamera(cam.id);
          });
        }
        
        document.getElementById(`duration-${cam.id}`)?.addEventListener('input', (e) => {
            const newDuration = parseInt((e.target as HTMLInputElement).value, 10);
            if (!isNaN(newDuration) && newDuration >= 5) {
                cam.duration = newDuration;
            }
        });

        if (cam.status !== 'disconnected') {
          document
            .getElementById(`mute-cam-${cam.id}`)
            ?.addEventListener('click', () => toggleCameraMute(cam.id));
          document.getElementById(`volume-${cam.id}`)?.addEventListener('input', (e) => {
              const newVolume = parseFloat((e.target as HTMLInputElement).value);
              handleVolumeChange(cam.id, newVolume);
          });
          document
            .getElementById(`pause-cam-${cam.id}`)
            ?.addEventListener('click', () => toggleCameraPause(cam.id));
          document
            .getElementById(`disconnect-cam-${cam.id}`)
            ?.addEventListener('click', () => disconnectCamera(cam.id));
        }
      });
      
      const directorViewEl = document.querySelector('.director-view');
      const cameraStripEl = document.querySelector('.camera-strip');
      if (directorViewEl && currentScroll.director) directorViewEl.scrollTop = currentScroll.director;
      if (cameraStripEl && currentScroll.cameraStrip) cameraStripEl.scrollLeft = currentScroll.cameraStrip;

      appContainer.className = appState.director.isLive ? 'fullscreen-live' : '';
      if (appState.director.isLive && (appState.director.isPaused || appContainer.matches(':hover'))) {
          appContainer.classList.add('controls-visible');
      }

      if (appState.director.liveCameraId) {
        document
          .getElementById(`camera-slot-${appState.director.liveCameraId}`)
          ?.classList.add('live');
        const liveOutput = document.getElementById(
          'live-output',
        ) as HTMLVideoElement;
        const liveCam = appState.director.cameras.find(
          (c) => c.id === appState.director.liveCameraId,
        );
        if (liveOutput && liveCam?.stream) {
          liveOutput.srcObject = liveCam.stream;
          liveOutput.volume = liveCam.isMuted ? 0 : liveCam.volume;
        }
      }
      break;
    case 'camera':
      appContainer.className = '';
      const isLiveForTally = appState.director.liveCameraId === appState.camera.connectedCameraId;
      if (!appState.camera.isPreviewActive) {
        // State 1: Before camera is started
        appContainer.innerHTML = `
          ${renderHeader('camera')}
          <div class="camera-view camera-setup-view">
            <div class="connection-form">
              <h2>Connect to Director</h2>
              <p>1. Enter 4-digit code from Director screen.</p>
              <input type="text" id="code-input" maxlength="4" placeholder="----">
              <p>2. Start your camera to get a preview.</p>
              <button id="start-camera-btn" class="btn"><i class="fa-solid fa-video"></i> Start Camera & Preview</button>
            </div>
          </div>
        `;
        document.getElementById('start-camera-btn')?.addEventListener('click', () => {
            const codeInput = document.getElementById('code-input') as HTMLInputElement;
            if (codeInput && codeInput.value.trim().length === 4) {
                appState.camera.enteredCode = codeInput.value.trim();
                startCameraPreview();
            } else {
                alert('Please enter a valid 4-digit code.');
                if (codeInput) codeInput.focus();
            }
        });
      } else {
        // State 2: Camera is active, operator view
        const isDirectorOnSameDevice = appState.director.cameras.length > 0;
        appContainer.innerHTML = `
          <div class="camera-view camera-operator-view ${isLiveForTally ? 'is-live' : ''}">
             ${
                appState.camera.isPausedByOperator
                ? '<div class="camera-operator-paused-overlay">PAUSED</div>'
                : ''
            }
            <div class="tally-light-overlay"></div>
            <video id="camera-preview" autoplay muted></video>
            <div class="camera-operator-status">
              ${
                appState.camera.isConnected
                ? `<span class="status-chip ${isLiveForTally ? 'live' : 'connected'}"><i class="fa-solid ${isLiveForTally ? 'fa-signal-stream' : 'fa-check'}"></i> ${isLiveForTally ? 'LIVE' : 'Connected'}</span>`
                : '<span class="status-chip">Previewing</span>'
              }
            </div>
            ${
              !appState.camera.isConnected
              ? `
              <div class="camera-connect-prompt">
                <button id="connect-btn" class="btn"><i class="fa-solid fa-link"></i> Connect with Code</button>
              </div>`
              : ''
            }
            <div class="camera-operator-controls">
                ${
                 appState.camera.isConnected && isDirectorOnSameDevice ? `
                 <button id="go-to-director-btn" class="cam-control-btn text-btn" title="Switch to Director View">
                    <i class="fa-solid fa-user-tie"></i> Director View
                 </button>
                 ` : ''
                }
               <button id="flip-camera-btn" class="cam-control-btn" title="Flip Camera">
                  <i class="fa-solid fa-camera-rotate"></i>
               </button>
               ${
                 appState.camera.isConnected ? `
                 <button id="pause-operator-btn" class="cam-control-btn" title="${appState.camera.isPausedByOperator ? 'Resume Stream' : 'Pause Stream'}">
                    <i class="fa-solid ${appState.camera.isPausedByOperator ? 'fa-play' : 'fa-pause'}"></i>
                 </button>
                 ` : ''
               }
               <button id="stop-camera-btn" class="cam-control-btn disconnect" title="Stop & Disconnect">
                  <i class="fa-solid fa-stop"></i>
               </button>
            </div>
          </div>
        `;
        const videoPreview = document.getElementById('camera-preview') as HTMLVideoElement;
        if (appState.camera.localStream) {
            videoPreview.srcObject = appState.camera.localStream;
            videoPreview.play();
        }
        document.getElementById('go-to-director-btn')?.addEventListener('click', () => renderView('director'));
        document.getElementById('flip-camera-btn')?.addEventListener('click', flipCamera);
        document.getElementById('pause-operator-btn')?.addEventListener('click', toggleOperatorPause);
        document.getElementById('stop-camera-btn')?.addEventListener('click', stopCameraViewConnection);
        document.getElementById('connect-btn')?.addEventListener('click', () => {
            const code = appState.camera.enteredCode;
            if (code.length === 4 && appState.camera.localStream) {
              const connectedId = connectCameraByCode(code, appState.camera.localStream);
              if (connectedId !== null) {
                appState.camera.isConnected = true;
                appState.camera.connectedCameraId = connectedId;
                renderView('camera'); // Re-render to show connected state
              } else {
                alert('Invalid code or slot is already taken. Please try again.');
              }
            } else {
              alert('Connection failed. Please stop the camera and try again with a valid code.');
            }
        });
      }
      document
        .getElementById('home-btn')
        ?.addEventListener('click', () => renderView('landing'));
      document
        .getElementById('switch-to-director-btn')
        ?.addEventListener('click', () => renderView('director'));
      break;
  }
}

// --- INITIALIZATION ---
function init() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    alert(
      'Your browser does not support the necessary features for this app.',
    );
    return;
  }
  
  appContainer.addEventListener('mouseenter', () => {
    if (appContainer.classList.contains('fullscreen-live')) {
        appContainer.classList.add('controls-visible');
    }
  });
  appContainer.addEventListener('mouseleave', () => {
      if (appContainer.classList.contains('fullscreen-live') && !appState.director.isPaused) {
          appContainer.classList.remove('controls-visible');
      }
  });

  renderView('landing');
}

init();